# Softwrap
Dynamics for retopology.

This is an alpha version, probably full of bugs, use at your own risk.

Softwrap is now finished for windows, and you can get it at BlenderMarket.

https://blendermarket.com/products/softwrap

# considerations before using:
 * This is a slow addon, decimate your sculpt before using it
 * Make sure your models are roughly the same scale and aligned to make transfer easier.
 * You can use proportional or sculpt to make models more similar in case there's a big shape discrepancy
 * Dont swap Target Mesh and Source Mesh, Target is your sculpt, Source is your quads mesh.

# instalation
 * Click clone or download
 * select download zip
 * open blender user preferences
 * open addons tab
 * hit install
 * select the downloaded zip file
 * enable the addon.
