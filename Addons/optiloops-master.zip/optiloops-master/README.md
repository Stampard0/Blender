# optiloops
Optiloops is a blender 3d addon for optimizing topology.

It goes through loops of the mesh and removes loops selectively by several constraints:
  -max face angle present on the loop
  keep by:
    -seams
    -loops essentials for subsurf shape (offset edges)
