def get_exchange_path():
    return ''