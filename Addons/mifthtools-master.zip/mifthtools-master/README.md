# mifthtools
This is my repository of tools which i use.

Exchangers:
http://blenderartists.org/forum/showthread.php?378946-Modo-Blender-Exchanger
http://community.thefoundry.co.uk/discussion/topic.aspx?f=119&t=114220

Blender:

MiraTools - Modeling/Retopo tools dedicated to my daughter.
http://blenderartists.org/forum/showthread.php?366107-MiraTools

MifthTools - many tools which i use every day. Cloning, Animation.
http://blenderartists.org/forum/showthread.php?346588-MifthTools-Addon

SuperGrouper - Simple Grouping System. Forget about 20 layers limitation.
http://blenderartists.org/forum/showthread.php?360257-Super-Grouper-WIP

Simple3DCoat Applink - Applink for Blender/3DCoat integration.
http://3d-coat.com/forum/index.php?showtopic=15481

Thanks.
